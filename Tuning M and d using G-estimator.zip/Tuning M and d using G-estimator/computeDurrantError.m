%Return empirical error rate
function errorDurrant=computeDurrantError(d,p,M,X0,X1,X0_test,X1_test)
    ensemble=randn(d,p,M)/sqrt(d);
    n0=size(X0,2);n1=size(X1,2);n=n0+n1;
    n0_test=size(X0_test,2);n1_test=size(X1_test,2);n_test=n0_test+n1_test;
    piHat0=n0/n;piHat1=n1/n;
    L0=zeros(M,n0_test);L1=zeros(M,n1_test);%will hold single RP-LDA discriminants for test points in each class
    for k=1:M 
        Rk=ensemble(:,:,k);
        X0_proj_k=Rk*X0;X1_proj_k=Rk*X1;
        muHat0_proj_k=sum(X0_proj_k,2)/n0;muHat1_proj_k=sum(X1_proj_k,2)/n1;muHat_proj_k=muHat1_proj_k-muHat0_proj_k;
        SigmaHat_proj_k=pooledSampleCovariance(X0_proj_k,X1_proj_k,muHat0_proj_k,muHat1_proj_k,n0,n1);
        invSigmaHat_proj_k=inv(SigmaHat_proj_k);
        wk=muHat_proj_k'*invSigmaHat_proj_k;%kth weight vector
        L0(k,:)=wk*(Rk*X0_test-(muHat0_proj_k+muHat1_proj_k)/2*ones(1,n0_test))+log(piHat1/piHat0);
        L1(k,:)=wk*(Rk*X1_test-(muHat0_proj_k+muHat1_proj_k)/2*ones(1,n1_test))+log(piHat1/piHat0);
    end

    
    %Compute classifier scores
    if(M==1)
        scoresC0_Durrant=L0;scoresC1_Durrant=L1;
    else
        scoresC0_Durrant=mean(L0);scoresC1_Durrant=mean(L1);
    end
    
    %Predict classes
    decC0_Durrant=scoresC0_Durrant>0;decC1_Durrant=scoresC1_Durrant>0;
    
    %Compute error rates
    errorDurrant=(sum(decC0_Durrant)+sum(1-decC1_Durrant))/n_test;
    
end