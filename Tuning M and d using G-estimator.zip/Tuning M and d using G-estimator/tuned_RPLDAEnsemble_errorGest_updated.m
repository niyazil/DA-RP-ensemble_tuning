%This function returns the d yielding the minimum error by G-estimator of the error. It works for M=1, M finite, and M=Inf. The argument 'increment' refers to how you want to increment d up till n-4.
%The argument 'upto' refers to how high you want to go with the d. 

function [dopt,minErrorGest,d,errorGest]=tuned_RPLDAEnsemble_errorGest_updated(M,p,n0,n1,X0,X1,increment,upto)
    d=1:increment:upto;
    errorGest=zeros(size(d));
    parfor i=1:length(d)
        errorGest(i)=computeErrorGest_RPLDAEnsemble_updated_v2(M,p,d(i),n0,n1,X0,X1);
    end
    [minErrorGest,i_minErrorGest]=min(errorGest);
    dopt=d(i_minErrorGest);
end