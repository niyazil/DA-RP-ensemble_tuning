
function avgTestingError=computeDurrantError_withAveraging(numTrials,d,p,M,X0,X1,X0_test,X1_test)
    testingError=zeros(numTrials,1);
    parfor i=1:numTrials
        testingError(i)=computeDurrantError(d,p,M,X0,X1,X0_test,X1_test);
    end
    avgTestingError=mean(testingError);
    
end