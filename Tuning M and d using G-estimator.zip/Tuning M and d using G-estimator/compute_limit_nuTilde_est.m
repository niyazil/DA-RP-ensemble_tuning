%computes lim beta->0 nuTilde(beta) as a function of training

function lim_nuTilde_est=compute_limit_nuTilde_est(p,d,D)
    %implement the bisection method to find the root
    a=0;b=5;
%     hh=@(y)(1/d)*trace(inv(eye(p)+y*D))-(p/d)+1;
    hh=@(y)(1/d)*sum(1./(1+y*diag(D)))-(p/d)+1;%more efficient

    hh_a=hh(a);hh_b=hh(b);

    while(hh_a*hh_b>0)%if hh(a) and hh(b) have the same sign, then make b bigger
        b=1.5*b;
        hh_b=hh(b);
    end

    %Ok so now I've identified [a,b]
    %Now gotta split at each turn
    tol=1e-6;
    c=(a+b)/2;

    while(abs(a-b)>tol)
        hh_c=hh(c);
        if(hh_a*hh_c<0)
            b=c;
            hh_b=hh_c;
        else
            a=c;
            hh_a=hh_c;
        end
         c=(a+b)/2;
    end
    
    y=c;

    lim_nuTilde_est=y;
end