The script 'example.m' uses synthetic data to demonstrate the tuning procedure for d and M based on the classification error G-estimator. All other files in this folder are supporting functions.

For the files 'qdwh.m' and 'qdwheig.m', we cite:

Yuji Nakatsukasa (2022). Symmetric eigenvalue decomposition and the SVD (https://www.mathworks.com/matlabcentral/fileexchange/36830-symmetric-eigenvalue-decomposition-and-the-svd), MATLAB Central File Exchange. Retrieved November 1, 2022.
