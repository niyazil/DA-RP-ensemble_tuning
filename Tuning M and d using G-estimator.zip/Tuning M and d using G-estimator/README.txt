The script 'example.m' uses synthetic data to demonstrate the tuning procedure for d and M based on the classification error G-estimator. All other files in this folder are supporting functions.
