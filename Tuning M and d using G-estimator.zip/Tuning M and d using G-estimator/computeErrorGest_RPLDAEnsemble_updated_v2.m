%This function computes and returns the error -estimator for a Durrant RP-LDA
%ensemble. It works for M=1, M finite, and M=Inf.

function errorGest=computeErrorGest_RPLDAEnsemble_updated_v2(M,p,d,n0,n1,X0,X1)
    n=n0+n1;piHat0=n0/n;piHat1=n1/n;
    muHat0=sum(X0,2)/n0;muHat1=sum(X1,2)/n1;muHat=muHat1-muHat0;
    SigmaHat=pooledSampleCovariance(X0,X1,muHat0,muHat1,n0,n1);
    [~,D]=qdwheig(SigmaHat);
    
    lim_nuTilde=compute_limit_nuTilde_est(p,d,D);%estimator of lim beta-->0 nuTilde1(beta)
    temp1=inv(SigmaHat+1/lim_nuTilde*eye(p));
    temp2=trace(SigmaHat*temp1);
    
    %G-estimator of m0 and m1
    m0Gest=-0.5*muHat'*temp1*muHat+(1/(n0-1)*temp2)/(1-1/(n-2)*temp2)+log(piHat1/piHat0);
    m1Gest=0.5*muHat'*temp1*muHat-(1/(n1-1)*temp2)/(1-1/(n-2)*temp2)+log(piHat1/piHat0);
    
    if(M~=1)%this term does not appear when M=1
    %G-estimator of covariance term of single RPLDA
    covTermGest=(1-1/M)*(1+(1/(n-2)*temp2)/(1-1/(n-2)*temp2))^2*muHat'*temp1*SigmaHat*temp1*muHat;
    end
    
    if(M~=Inf)%this term does not appear when M=Inf
        %G-estimator of variance of single RPLDA
        term1=(1/(1-1/(n-2)*temp2))^2*muHat'*temp1*SigmaHat*temp1*muHat;
        term2=1/lim_nuTilde^2*(1/(1-1/(n-2)*temp2))^2*(1/d)*trace(temp1*SigmaHat*temp1)/(1-1/d*trace(SigmaHat*temp1*SigmaHat*temp1))*muHat'*temp1^2*muHat;
        varTermGest=(1/M)*(term1+term2);
    end
    
    %G-estimator of sigma^2
    if(M==1)
        sigmaGest=varTermGest;
    elseif(M==Inf)
        sigmaGest=covTermGest;
    else
        sigmaGest=varTermGest+covTermGest;
    end
    
    %Error G-estimator
    errorGest=piHat0*(1-qfunc(m0Gest/sqrt(sigmaGest)))+piHat1*(1-qfunc(-m1Gest/sqrt(sigmaGest)));
end