% This script uses synthetic data to demonstrate the tuning procedure for d and M based on the classification error G-estimator for d
% and the approximation of this G-estimator using the Lambert W function for M.

% The steps are:
% Step 1-Tune d based on infinite ensemble error G-estimator
% Step 2-Set desired ratio phi of infinite error G-estimator to the finite error G-estimator
% Step 3-For d found in Step 1, solve for M which yields the phi set at
% Step 2 (using the approximation)

% Note the derivation of the approximation in Step 3 assumes equal priors and sample size for
% each class.

clear all
clc
rng('default')

%% Parameters
p=1000;n=100;pi0=0.5;pi1=1-pi0;numTrials=500;
n0=ceil(pi0*n);n1=n-n0;
%true statistics
Sigma=(10/p)*ones(p)+0.1*eye(p);
mu0=[ones(ceil(sqrt(p)),1);zeros(p-ceil(sqrt(p))-2,1);2*ones(2,1)]/p^(1/4);mu1=zeros(size(mu0));mu=mu1-mu0;

%% Bayes Error
bayesError=qfunc(0.5*sqrt(mu'*inv(Sigma)*mu));

%% Generate training data 
[X0,X1,n0,n1]=trainingSampleGenerator(mu0,mu1,Sigma,n,pi0);
piHat0=n0/n;piHat1=n1/n;
muHat0=sum(X0,2)/n0;muHat1=sum(X1,2)/n1;muHat=muHat1-muHat0;
SigmaHat=pooledSampleCovariance(X0,X1,muHat0,muHat1,n0,n1);
X=[X0 X1]';y=[zeros(n0,1);ones(n1,1)];categories=[0;1];

%% Generate testing data
nTest=2e5;
[X0_test,X1_test,n0_test,n1_test]=trainingSampleGenerator(mu0,mu1,Sigma,nTest,pi0);

%% Tune d by G-estimators and set M according to approximation
%Tune d according to G-estimator of infinite ensemble
increment=5;upto=rank(SigmaHat);
[dopt_inf,minErrorGest_inf,d_inf,errorGest_inf]=tuned_RPLDAEnsemble_errorGest_updated(Inf,p,n0,n1,X0,X1,increment,upto);

%Compute M which gives performance phi according to G-estimator
%approximation
phi=0.95;
[~,m1_Gest,sigma1_Gest,sigmaInf_Gest]=computeGestimators_updated(dopt_inf,X0,X1);
x_sq=m1_Gest^2/sigmaInf_Gest;
W0=lambertw(phi^2*x_sq*exp(x_sq));
M=ceil((sigma1_Gest-sigmaInf_Gest)*W0/(m1_Gest^2-sigmaInf_Gest*W0));

dopt_finite=dopt_inf; %set to same as infinite

%% Compute and report the average testing error
%Compute testing error averaged over 'numTrials' sets of random projections 
avgError_finite=computeDurrantError_withAveraging(numTrials,dopt_finite,p,M,X0,X1,X0_test,X1_test);

disp(['The Bayes error is ',num2str(bayesError)]);
disp(['By tuning based on the heuristic, we can get ',num2str(avgError_finite), '(M=',num2str(M),', d=',num2str(dopt_finite),')'])

