%This functions computes and returns the G-estimators of m0, m1, sigma(1),
%and sigma_inf

%Note NOT the same as the function with same name in the folder '3-16-2022'
%whch returns the G-estimator for m0, m1, and sigma(M).

%Note this has been updated so that code from old work is updated to new
%notation for consistency in normalztions. Gives better results.

function [m0_Gest,m1_Gest,sigma1_Gest,sigmaInf_Gest]=computeGestimators_updated(d,X0,X1)
    p=size(X0,1);n0=size(X0,2);n1=size(X1,2);n=n0+n1;
    piHat0=n0/n;piHat1=n1/n;
    muHat0=sum(X0,2)/n0;muHat1=sum(X1,2)/n1;muHat=muHat1-muHat0;
    SigmaHat=pooledSampleCovariance(X0,X1,muHat0,muHat1,n0,n1);[~,D]=qdwheig(SigmaHat);
    
    lim_nuTilde=compute_limit_nuTilde_est(p,d,D);%estimator of lim beta-->0 nuTilde1(beta)
    temp1=inv(SigmaHat+1/lim_nuTilde*eye(p));
    temp2=trace(SigmaHat*temp1);

    %G-estimators of m0 and m
    m0_Gest=-0.5*muHat'*temp1*muHat+(1/(n0-1)*temp2)/(1-1/(n-2)*temp2)+log(piHat1/piHat0);
    m1_Gest=0.5*muHat'*temp1*muHat-(1/(n1-1)*temp2)/(1-1/(n-2)*temp2)+log(piHat1/piHat0);
    
    %G-estimator of covariance term of single RPLDA
    sigmaInf_Gest=(1+(1/(n-2)*temp2)/(1-1/(n-2)*temp2))^2*muHat'*temp1*SigmaHat*temp1*muHat;
    
    %G-estimator of variance of single RPLDA
    term1=(1/(1-1/(n-2)*temp2))^2*muHat'*temp1*SigmaHat*temp1*muHat;
    term2=1/lim_nuTilde^2*(1/(1-1/(n-2)*temp2))^2*(1/d)*trace(temp1*SigmaHat*temp1)/(1-1/d*trace(SigmaHat*temp1*SigmaHat*temp1))*muHat'*temp1^2*muHat;
    sigma1_Gest=term1+term2;
    
end